using System.Net.NetworkInformation;
using System.Text;
using System.Threading;

namespace NetworkMonitor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns.Add("ipColumn", "IP List");
            dataGridView1.DefaultCellStyle.Font = new Font("Segoe Fluent Icons", 13);

            dataGridView2.RowHeadersVisible = false;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.Columns.Add("statusColumn", "Status");
            dataGridView2.DefaultCellStyle.Font = new Font("Segoe Fluent Icons", 13);
        }

        private void TextBoxAppend()
        {
            dataGridView1.Rows.Add(textBox1.Text);
            textBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TextBoxAppend();
        }


        private void RowMethod()
        {

            while(true)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        try
                        {
                            string value = cell.Value?.ToString();
                            if (value?.ToString().Trim() != "")
                            {
                                Ping pingSender = new Ping();
                                PingOptions options = new PingOptions();

                                // Use the default Ttl value which is 128,
                                // but change the fragmentation behavior.
                                options.DontFragment = true;

                                // Create a buffer of 32 bytes of data to be transmitted.
                                string data = "aaa";
                                byte[] buffer = Encoding.ASCII.GetBytes(data);
                                int timeout = 120;
                                PingReply reply = pingSender.Send(value, timeout, buffer, options);
                                if (reply.Status == IPStatus.Success)
                                {
                                    dataGridView1.Invoke((MethodInvoker)(() => dataGridView2.Rows.Add($"Success: {value}")));
                                }
                                else
                                {
                                    dataGridView1.Invoke((MethodInvoker)(() => dataGridView2.Rows.Add($"Failed: {value}")));
                                }


                            }

                        }

                        catch (Exception)
                        {
                            continue;
                        }

                    }
                }

                Thread.Sleep(10000);

            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Thread t3 = new Thread(() => RowMethod());
            t3.Start();
        }
    }
}